<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <style>
            #title{
                position: absolute;
                left: 100px;
                top: 120px;
                width: 400px;
            }
            #did{
                position: absolute;
                left: -80px;
                width: 400px;
            } 
            #title1{
                position: absolute;
                left: 800px;
                top: 120px;
                width: 400px;
            }
            #did1{
                position: absolute;
                left: -80px;
                width: 400px;
            }
            #details{
                position: absolute;
                top: 250px;
                left: 30px;
            }
            #show{
                position: absolute;
                left: 730px;
                top: 250px;
            }
        </style>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Generate Report</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <a class="navbar-brand" style="padding-left:900px" href="/publish.php"><font color="white">Publish Notification</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div id="title"> <h3>Student Details</h3><hr id="did"></div>
        <div id="details">
            <?php
                $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
                $name=$_GET['name'];
                $id=$_GET['ID'];
                $result=mysqli_query($con,"select * from student where Name='$name'&& ID='$id'");
                $num=mysqli_num_rows($result);
                if($num!=1){
                    echo '<script> alert("Please enter a valid name"); </script>';
                    header('refresh:.2 url="/reallocation.php"');
                }
                while($row=mysqli_fetch_assoc($result)){
                    echo "<h5 style='text-transform: uppercase;'><b>Name :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Name']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>ID :</b>&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['ID']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Gender :</b>&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Gender']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Department :</b>&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Department']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Phone Number :</b>&emsp;&emsp;&emsp;&emsp;".$row['PhoneNO']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Building :</b>&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['BuildingName']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Room Number :</b>&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;".$row['RoomNO']."</h5>";
                    echo "<h5 style='text-transform: uppercase;'><b>Goverment ID :</b>&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;".$row['GovtID']."</h5>";
                }
            ?>
        </div>
        <div id="title1"> <h3>Rooms Available</h3><hr id="did1"></div>
        <div id="show">
            <?php
                $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
                $name=$_GET['name'];
                $id=$_GET['ID'];
                $res=mysqli_query($con,"select * from student where Name='$name'&& ID='$id'");
                $num=mysqli_fetch_assoc($res);
                $gender=$num['Gender'];
                $name=$num['BuildingName'];
                $room=$num['RoomNO'];
                $result=mysqli_query($con,"select * from empty_room where Room_Number<>$room || Building_Name<>'$name'");
                while($row=mysqli_fetch_assoc($result)){
                    if($row['Empty']!=0){
                        echo "<h5><b>Room Number :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;".$row['Room_Number']."</h5>";
                        echo "<h5><b>Type :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Type']."</h5>";
                        echo "<h5><b>Building Name :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;".$row['Building_Name']."</h5>";
                        echo "<h5><b>Capacity :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;".$row['Capacity']."</h5>";
                        echo "<h5><b>Rooms Available : </b>&emsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;".$row['Empty']."</h5>";
                        echo "<h5><b>Floor : </b>&emsp;&emsp;&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;&emsp;&emsp;&emsp;".$row['Floor']."</h5>
                        <center><a class='btn btn-info btn-sm' href='reallocateRoom.php?roomNo=".$row['Room_Number']."&bNo=".$row['Building_Name']."&PreviousbNo=".$name."&PreviousRNo=".$room."&studentID=".$id."&type=".$row['Type']."&gender=".$gender."'>Book</a></center><hr>";
                    }
                }
            ?>
        </div>
        
    </body>
</html>