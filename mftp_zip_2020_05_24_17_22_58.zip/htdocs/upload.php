<?php
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $message=$_POST['notification'];
    $user=$_GET['user'];
    $date=date('d-m-y');
    //echo $date;
    mysqli_query($con,"insert into notification values('','$user','$message','$date')");
    //echo $message;
    header("location:/publish.php");
?>