<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/Student/studentlogin.html');
    }
?>
<html>
    <head>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Home</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <a class="navbar-brand" style="padding-left:900px" href="/logout.php"><font color="white">Logout</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 300px;">
            <div class="card-body">
                <img src="/Student/notifications.png" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="/Student/notification.php">View Notification</a></p></center>
            </div>
        </div>
        
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 730px;">
            <div class="card-body">
                <img src="/Student/query.png" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="/Student/query.php">Post a Query</a></p></center>
            </div>
        </div>
        
        </div>
    </body>
</html>