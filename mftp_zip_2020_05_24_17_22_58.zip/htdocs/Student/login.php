<?php
    session_start();
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $id=$_POST['id'];
    $phone=$_POST['phone'];
    $query="select * from student where ID='$id' && PhoneNO= $phone";
    $res=mysqli_query($con, $query);
    $num=mysqli_num_rows($res);
    if($num==1){
        $_SESSION['user']=$id;
        header('location:\Student\home.php');
    }
    else{
        echo '<script> alert("Wrong ID/Phone number"); </script>';
        header('refresh:.02;url=\Student\studentlogin.html');
    }
    
?>