<?php
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $message=$_POST['notification'];
    $user="Student";
    $date=date('d-m-y');
    $time=date('h:i:s');    
    mysqli_query($con,"insert into query values('$user','$message','$date','$time')");
    header("location:/Student/query.php");
?>