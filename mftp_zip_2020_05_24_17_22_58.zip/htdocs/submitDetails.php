<?php
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $id=$_POST['ID'];
    $name=$_POST['Name'];
    $govtid=$_POST['GovtID'];
    $phone=$_POST['Phone'];
    $building=$_GET['building'];
    $room=$_GET['roomNo'];
    $dept=$_POST['Dept'];
    $type=$_GET['type'];
    $gender=$_POST['Gender'];
    if($gender!=$type){
        echo "<script> alert('You cannot allot this room to this person')</script>";
        header('loaction:/home.php');
    }
    else{
        $query="select * from empty_room where Room_Number=$room && Building_Name= '$building'";
        $result=mysqli_query($con,$query);
        $result=mysqli_fetch_array($result);
        $filled=$result['Filled']+1;
        $empty=$result['Empty']-1;
        $row=mysqli_num_rows(mysqli_query($con,"select * from student where ID='$id'"));
        if($row>=1){
            echo '<script> alert("Student with such details exists!!!"); </script>';
            header('refresh:.2;url= /home.php');
        }
        else{
            mysqli_query($con,"update empty_room set Filled=$filled, Empty=$empty where Room_Number=$room && Building_Name='$building'");
            $query="insert into student values('$id','$name','$govtid','$phone','$building','$room','$dept','$gender')";
            mysqli_query($con,$query);
            //echo $query;
            header('refresh:.02;url= /home.php');
        }
    }
?>