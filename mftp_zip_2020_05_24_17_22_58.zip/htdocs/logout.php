<?php
    session_start();
    session_destroy();
    header('refresh:.001;url=\index2.html');
?>