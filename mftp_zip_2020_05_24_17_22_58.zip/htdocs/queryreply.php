<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Query</title>
    <style>
        #notification{
            position: absolute;
            left: 10px;
            top: 130px;
            resize: none;
        }
        #post{
            position: absolute;
            left: 430px;
            top: 230px;
        }
        #content{
            position: absolute;
            left: 600px;
            top: 130px;
        }
    </style>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <!--a class="navbar-brand" style="padding-left:900px" href="/publish.php"><font color="white">Publish Notification</font></a-->
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div id="content">
            <div class="card" style="width: 30rem;">
                <div class="card-body">
                <h3 class="card-title"><center>Recent Query</center></h3><br>
                    <?php
                        $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
                        $result=mysqli_query($con,"select * from query order by Time desc");
                        while($row=mysqli_fetch_assoc($result)){
                            echo '<font color="orange">'.$row['Name'].'</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;'.$row['Date'].'<hr>';
                            echo '<div style="padding-left:10px;">'.$row['Query'].'</div><br>';
                        }
                    ?>
                </div>
            </div>
        </div>
        <form method="post" action="/uploadquery.php">
            <textarea id="notification" name="notification" rows="10" cols="50"></textarea>
            <input type="submit" id="post" class="btn btn-danger btn-sm" value="PUBLISH">
        </form>
        
    </body>
</html>