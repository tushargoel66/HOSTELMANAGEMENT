<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <style>
            #Id{
                position: absolute;
                left: 400px;
                top: 250px;
                width: 400px;
            }
            #Name{
                position: absolute;
                left: 400px;
                top: 340px;
                width: 400px;
            }
            #title{
                position: absolute;
                left: 410px;
                top: 120px;
                width: 400px;
            }
            #did{
                position: absolute;
                left: -20px;
                width: 400px;
            }
            #in{
                position: absolute;
                left: 400px;
                top: 440px;
                width: 400px;
            }
        </style>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Reallocation</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <a class="navbar-brand" style="padding-left:900px" href="/publish.php"><font color="white">Publish Notification</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div id="title"> <h3>Student details for reallocation</h3><hr id="did"></div>
        
        <form action="getReportForReallocation.php" method="GET">
            <input type="text" id="Id" name="ID" placeholder="ID" autocomplete="off" style="text-transform: uppercase;" autofocus required >
            <br><br>
            <input type="text" id="Name" name="name" placeholder="Name" autocomplete="off" style="text-transform: uppercase;" autofocus required>
            <br><br>
            <input type="submit" id="in" class="btn btn-danger btn-block btn-sm">
        </form>
        
    </body>
</html>