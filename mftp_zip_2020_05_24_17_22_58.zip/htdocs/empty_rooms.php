<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <style>
            #show{
                position: absolute;
                left: 420px;
                top: 190px;
            }
            #genmale{
                position: absolute;
                width: 40rem;
                left: -300px;
                
            }
            #genfemale{
                position: absolute;
                width: 40rem;
                left: 300px;
                
            }
        </style>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Home</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <a class="navbar-brand" style="padding-left:900px" href="/publish.php"><font color="white">Publish Notification</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <br>
        <center><h3>Rooms Available</h3></center>
        <hr>
        <div id="show">
            <div id="genmale">
                <?php
                    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
                    $result=mysqli_query($con,"select * from empty_room where Type='Male'");
                    while($row=mysqli_fetch_assoc($result)){
                        if($row['Empty']!=0){
                            echo "<h5><b>Room Number :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Room_Number']."</h5>";
                            echo "<h5><b>Building Name :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Building_Name']."</h5>";
                            echo "<h5><b>Type :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;".$row['Type']."</h5>";
                            echo "<h5><b>Capacity :</b>&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Capacity']."</h5>";
                            echo "<h5><b>Rooms Available :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Empty']."</h5>";
                            echo "<h5><b>Floor :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Floor']."</h5><hr>";
                        }
                    }
                ?>
            </div>
            <div id="genfemale">
                <?php
                    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
                    $result=mysqli_query($con,"select * from empty_room where Type='Female'");
                    while($row=mysqli_fetch_assoc($result)){
                        if($row['Empty']!=0){
                            echo "<h5><b>Room Number :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Room_Number']."</h5>";
                            echo "<h5><b>Building Name :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Building_Name']."</h5>";
                            echo "<h5><b>Type :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;".$row['Type']."</h5>";
                            echo "<h5><b>Capacity :</b>&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Capacity']."</h5>";
                            echo "<h5><b>Rooms Available :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Empty']."</h5>";
                            echo "<h5><b>Floor :</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;".$row['Floor']."</h5><hr>";
                        }
                    }
                ?>
            </div>
        </div>
    </body>
</html>