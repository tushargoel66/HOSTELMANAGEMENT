<?php
    session_start();
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $user=$_POST['user'];
    $mail=md5($user);
    $password=md5($_POST['password']);
    $query="select * from admin_info where Email='$mail'&& Password='$password'";
    $res=mysqli_query($con, $query);
    $num=mysqli_num_rows($res);
    if($num==1){
        $_SESSION["user"]=$user;
        header('location: /home.php');
    }
    else{
        echo '<script> alert("Wrong Email/Password"); </script>';
        header('refresh:.02;url= /index.html');
    }
    
?>