<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Home</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            
            <a class="navbar-brand" style="padding-left:600px" href="/queryreply.php"><font color="white">Query</font></a>
            <a class="navbar-brand" style="padding-left:50px" href="/publish.php"><font color="white">Publish Notification</font></a>
            <a class="navbar-brand" style="padding-left:50px" href="/logout.php"><font color="white">Logout</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 10px;">
            <div class="card-body">
                <img src="/Report.jpg" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="Report.php">Report Generation</a></p></center>
            </div>
        </div>
        
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 330px;">
            <div class="card-body">
                <img src="/Room-reallocation.jpg" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="reallocation.php">Room Reallocation</a></p></center>
            </div>
        </div>
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 650px;">
            <div class="card-body">
                <img src="/Rooms-empty.jpg" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="empty_rooms.php">Rooms Empty</a></p></center>
            </div>
        </div>
        <div class="card" style="position:absolute;width: 18rem;top: 200px; left: 970px;">
            <div class="card-body">
                <img src="/Room-allocation.jpg" style="width: 15rem;">
                <br><br>
                <center><p><a class="btn btn-info" href="allocation.php">Room Allocation</a></p></center>
            </div>
        </div>
    </body>
</html>