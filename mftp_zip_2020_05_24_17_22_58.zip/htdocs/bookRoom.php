<?php
    session_start();
    if(!isset($_SESSION['user'])){
        echo '<script> alert("Please login first"); </script>';
        header('refresh:.2;url=/index2.html');
    }
?>
<html>
    <head>
        <style>
            #title{
                position: absolute;
                left: 450px;
                top: 120px;
                width: 400px;
            }
            #feilds{
                position: absolute;
                top: 220px;
                left: 420px;
            }
            #did{
                position: absolute;
                left: -80px;
                width: 400px;
            }
        </style>
        <meta name="viewport" content="width=1020, initial-scale=1.0">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
        <title>Student Details</title>
    </head>
    <body>
        <nav class="navbar navbar-sm bg-info" style="position: relative;">
            <a class="navbar-brand" href="/home.php"><h3><font color="white">Manage</font></h3></a>
            <a class="navbar-brand" style="padding-left:900px" href="/publish.php"><font color="white">Publish Notification</font></a>
            <ul class="navbar-nav mr-auto"></ul>  
        </nav>
        <div id="title"> <h3>Details of the student</h3><hr id="did"></div>
        <div id="feilds">
            Room Number: &emsp;&emsp;&emsp;&emsp;<?php $room=$_GET['roomNo']; echo $room;?><br><br>
            Building: &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php $buliding=$_GET['bNo']; echo $buliding;?><br><br>
            <form action="submitDetails.php?<?php $buliding=$_GET['bNo']; $room=$_GET['roomNo']; $type=$_GET['type']; echo "roomNo=".$room."&&building=".$buliding."&&type=".$type; ?>" method="POST">
                Student ID :&emsp;&emsp;&emsp;&emsp; <input type="text" name="ID" placeholder="ID" autocomplete="off" style="text-transform: uppercase;" autofocus required >
                <br><br>
                Student Name : &emsp;&emsp;<input type="text" name="Name" placeholder="Name" autocomplete="off" style="text-transform: uppercase;" autofocus required>
                <br><br>
                Student Gender : <input type="text"  name="Gender" placeholder="Gender" autocomplete="off" style="text-transform: uppercase;" autofocus required>
                <br><br>
                Student Goverment ID : <input type="text"  name="GovtID" placeholder="Goverment ID" autocomplete="off" style="text-transform: uppercase;" autofocus required>
                <br><br>
                Student Phone Number : <input type="text" name="Phone" placeholder="Phone Number" autocomplete="off" style="text-transform: uppercase;" autofocus required>
                <br><br>
                Student Department : <input type="text" name="Dept" placeholder="Department" autocomplete="off" style="text-transform: uppercase;" autofocus required>
                <br><br>
                <center><input type="submit" id="in" class="btn btn-danger btn-sm" ></center>
            </form>
        </div>
        
    </body>
</html>