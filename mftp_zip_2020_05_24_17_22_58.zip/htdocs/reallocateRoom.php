<?php
    $con=mysqli_connect("sql211.epizy.com","epiz_25847689","CgYr9xDL3zvhh8u","epiz_25847689_hoste_management");
    $id=$_GET['studentID'];
    $previousRNO=$_GET['PreviousRNo'];
    $previousBNO=$_GET['PreviousbNo'];
    $newBno=$_GET['bNo'];
    $newRno=$_GET['roomNo'];
    $type=$_GET['type'];
    $gender=$_GET['gender'];
    if($type!=$gender){
        echo "<script> alert('This room cannot be alloted to this person!!!!'); </script>";
        header('refresh:.2;url=/home.php');
    }
    else{
        $res=mysqli_query($con,"select * from empty_room where Building_Name='$previousBNO'&&Room_Number=$previousRNO");
        $res=mysqli_fetch_assoc($res);
        $filled=$res['Filled']-1;
        $empty=$res['Empty']+1;
        mysqli_query($con,"update empty_room set Filled=$filled, Empty=$empty where Building_Name='$previousBNO'&&Room_Number=$previousRNO");
        $res=mysqli_query($con,"select * from empty_room where Building_Name='$newBno'&&Room_Number=$newRno");
        $res=mysqli_fetch_assoc($res);
        $filled=$res['Filled']+1;
        $empty=$res['Empty']-1;
        mysqli_query($con,"update empty_room set Filled=$filled, Empty=$empty where Building_Name='$newBno'&&Room_Number=$newRno");
        mysqli_query($con,"update student set RoomNO=$newRno, BuildingName='$newBno' where ID='$id'");
        header('refresh: .2; url=/home.php');
    }
?>